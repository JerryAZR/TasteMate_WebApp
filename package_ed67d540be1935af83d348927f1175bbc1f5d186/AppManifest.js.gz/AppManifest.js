var UnoAppManifest = {
    displayName: "TasteMate",
    splashScreenImage: "splash_screen.scale-200.png",
    splashScreenColor: "#ffffff",
}